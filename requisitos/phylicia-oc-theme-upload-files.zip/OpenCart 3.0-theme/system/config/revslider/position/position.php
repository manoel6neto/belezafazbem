<?php
$getpositions = array(
        'content_top' => 'Content Top',
        'content_bottom' => 'Content Bottom',
        'column_left' => 'Column Left',
        'column_right' => 'Column Right',
        'custom_pos' => 'Custom Position',
);
?>