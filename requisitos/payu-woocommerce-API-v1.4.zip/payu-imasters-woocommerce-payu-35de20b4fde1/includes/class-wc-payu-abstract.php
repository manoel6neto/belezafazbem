<?php

abstract class WC_PayU_Abstract extends WC_Payment_Gateway
{
    public function get_valid_value($value)
    {
        return preg_replace('/[^\d\.]+/', '', str_replace(',', '.', $value));
    }

    public function get_api_return_url($order)
    {
        global $woocommerce;

        $url = $woocommerce->api_request_url(get_class($this));

        return urlencode(add_query_arg(array(
            'key'   => $order->order_key,
            'order' => $order->id
        ), $url));
    }

    public function get_logger()
    {
        if (class_exists('WC_Logger')) {
            return new WC_Logger();
        } else {
            global $woocommerce;

            return $woocommerce->logger();
        }
    }

    public function order_items_payment_details($items, $order)
    {
        if ($this->id === $order->payment_method) {
            $card_brand              = get_post_meta($order->id, '_wc_payu_card_brand', true);
            $card_brand              = $this->get_payment_method_name($card_brand);
            $installments            = get_post_meta($order->id, '_wc_payu_installments', true);
            $order_id                = get_post_meta($order->id, '_wc_payu_order_id', true);
            $tid                     = get_post_meta($order->id, '_wc_payu_transaction_id', true);
            $status                  = get_post_meta($order->id, '_wc_payu_status', true);
            $boleto_url              = get_post_meta($order->id, '_wc_payu_boleto_url', true);
            $last                    = array_pop($items);
            $items['payment_return'] = array(
                'label' => 'Payment:',
                'value' => sprintf('<strong>Order ID</strong>: %s<br /><strong>Transaction Id</strong>: %s<br />',
                    $order_id, $tid)
            );

            if (!empty($boleto_url)) {
                $items['payment_return']['value'] .= sprintf('<br /><a class="button" href="%s">Imprima seu Boleto</a>',
                    $boleto_url);
            } else {
                $items['payment_return']['value'] .= sprintf('<strong>Status</strong>: %s', $status);

                if (method_exists($this, 'get_installment_text')) {
                    $items['payment_method']['value'] .= '<br />';
                    $items['payment_method']['value'] .= '<small>';
                    $items['payment_method']['value'] .= sprintf('%s e %s.', esc_attr($card_brand),
                        $this->get_installment_text($installments, (float)$order->get_total()));
                    $items['payment_method']['value'] .= '</small>';
                }
            }

            $items[] = $last;
        }

        return $items;
    }

    public function get_payment_method_name($slug)
    {
        $methods = $this->get_payment_methods();

        if (isset($methods[$slug])) {
            return $methods[$slug];
        }

        return $slug;
    }

    public function get_payment_methods()
    {
        return array(
            'visa'       => 'Visa',
            'mastercard' => 'MasterCard',
            'amex'       => 'American Express',
            'diners'     => 'Diners',
            'hipercard'  => 'Hipercard',
            'elo'        => 'Elo',
            'boleto'     => 'Boleto'
        );
    }

    public function payment_fields()
    {
        if ($description = $this->get_description()) {
            echo wpautop(wptexturize($description));
        }

        wp_enqueue_script('wc-credit-card-form');

        $this->get_checkout_form($this->get_order_total());
    }

    abstract protected function get_checkout_form($order_total = 0);

    public function get_order_total()
    {
        global $woocommerce;

        $order_total = 0;

        if (defined('WC_VERSION') && version_compare(WC_VERSION, '2.1', '>=')) {
            $order_id = absint(get_query_var('order-pay'));
        } else {
            $order_id = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;
        }

        if (0 < $order_id) {
            $order       = new WC_Order($order_id);
            $order_total = (float)$order->get_total();
        } elseif (0 < $woocommerce->cart->total) {
            $order_total = (float)$woocommerce->cart->total;
        }

        return $order_total;
    }

    public function process_payment($order_id)
    {
        $order = new WC_Order($order_id);

        return $this->process_payu_payment($order);
    }

    abstract protected function process_payu_payment($order);

    public function consult_order($order, $id, $tid, $status)
    {
        $json = $this->api->do_transaction_consultation($order, $tid, $id);

        if ($json->code == 'SUCCESS' && isset($json->result->payload)) {
            if ($json->result->payload->status != $status) {
                $this->process_order_status($order, $json->result->payload->status, 'verificação automática');
            }
        }
    }

    public function process_order_status($order, $status, $note = '')
    {
        $status_note = sprintf('PayU[%s]', $status);

        $order->add_order_note($status_note . ' ' . $note);

        switch ($status) {
            case 'APPROVED':
                $order->update_status('processing', $status_note);
                $order->payment_complete();
                break;
            case 'PENDING':
            case 'IN_PROGRESS':
                $order->update_status('on-hold', $status_note);
                break;
            case 'ERROR':
                $order->update_status('failed', $status_note);
            // no break
            case 'DECLINED':
            case 'EXPIRED':
                $order->update_status('cancelled', $status_note);

                break;
        }
    }

    public function thankyou_page($order_id)
    {
        $order = new WC_Order($order_id);

        if (defined('WC_VERSION') && version_compare(WC_VERSION, '2.1', '>=')) {
            $order_url = $order->get_view_order_url();
        } else {
            $order_url = add_query_arg('order', $order_id, get_permalink(woocommerce_get_page_id('view_order')));
        }

        if ($order->status == 'on-hold' || $order->status == 'processing' || $order->status == 'completed') {
            echo '<div class="woocommerce-message">Seu pedido já está sendo processado. Para mais informações, <a href="' . esc_url($order_url) . '" class="button" style="display: block !important; visibility: visible !important;">veja os detalhes do pedido</a><br /></div>';
        } else {
            echo '<div class="woocommerce-info">Para mais detalhes sobre seu pedido, acesse <a href="' . esc_url($order_url) . '">página de detalhes do pedido</a></div>';
        }
    }

    protected function validate_credit_brand($card_brand)
    {
        try {
            if (!in_array($card_brand, $this->card_types)) {
                throw new Exception(sprintf('Por favor, informe um cartão de crédito válido. As seguintes bandeiras são aceitas: %s.',
                    $this->get_accepted_brands_list($this->card_types)));
            }
        } catch (Exception $e) {
            $this->add_error($e->getMessage());

            return false;
        }

        return true;
    }

    public function get_accepted_brands_list($methods)
    {
        $total = count($methods);
        $count = 1;
        $list  = '';

        foreach ($methods as $method) {
            $name = $this->get_payment_method_name($method);

            if (1 == $total) {
                $list .= $name;
            } elseif ($count == ($total - 1)) {
                $list .= $name . ' ';
            } elseif ($count == $total) {
                $list .= sprintf('e %s', $name);
            } else {
                $list .= $name . ', ';
            }

            $count++;
        }

        return $list;
    }

    public function add_error($message)
    {
        global $woocommerce;

        $title = '<strong>' . esc_attr($this->title) . ':</strong> ';

        if (function_exists('wc_add_notice')) {
            wc_add_notice($title . $message, 'error');
        } else {
            $woocommerce->add_error($title . $message);
        }
    }

    protected function validate_card_number($card_number)
    {
        $card_number_checksum = '';

        foreach (str_split(strrev(preg_replace('/[^\d]/', '', $card_number))) as $i => $d) {
            $card_number_checksum .= $i % 2 !== 0 ? $d * 2 : $d;
        }

        if (array_sum(str_split($card_number_checksum)) % 10 !== 0) {
            throw new Exception('Por favor, informe um número válido de cartão de crédito');
        }

        return true;
    }

    protected function validate_card_fields($posted, $brand)
    {
        try {
            if (!isset($posted[$this->id . '_holder_name']) || '' === $posted[$this->id . '_holder_name']) {
                throw new Exception('Por favor informe o nome do titular do cartão');
            }

            if (preg_replace('/[^a-zA-Z\s]/', '',
                    $posted[$this->id . '_holder_name']) != $posted[$this->id . '_holder_name']) {
                throw new Exception('O nome do titular do cartão só pode conter letras');
            }

            if (!isset($posted[$this->id . '_expiry']) || '' === $posted[$this->id . '_expiry']) {
                throw new Exception('Por favor, informe a data de expiração do cartão');
            }

            if (strtotime(preg_replace('/(\d{2})\s*\/\s*(\d{4})/', '$2-$1-01',
                    $posted[$this->id . '_expiry'])) < strtotime(date('Y-m') . '-01')) {
                throw new Exception('A data de expiração do cartão deve ser futura');
            }

            if (!isset($posted[$this->id . '_cvc']) || '' === $posted[$this->id . '_cvc']) {
                throw new Exception('Por favor, informe o código de segurança do cartão');
            }

            if (preg_replace('/[^0-9]/', '', $posted[$this->id . '_cvc']) != $posted[$this->id . '_cvc']) {
                throw new Exception('O código de segurança deve conter apenas números');
            }

            if (($brand == 'amex' && strlen($posted[$this->id . '_cvc']) !== 4) || ($brand != 'amex' && strlen($posted[$this->id . '_cvc']) !== 3)) {
                $text = sprintf('São %d dígitos para %s', $brand == 'amex' ? 4 : 3, $brand);

                throw new Exception('Por favor, informe o código de segurança corretamente: ' . $text);
            }

            $this->validate_holder_doc($posted);
        } catch (Exception $e) {
            $this->add_error($e->getMessage());

            return false;
        }

        return true;
    }

    protected function validate_holder_doc($posted)
    {
        if (!isset($posted[$this->id . '_doc']) || '' === $posted[$this->id . '_doc']) {
            throw new Exception('Por favor informe o CPF ou CNPJ do titular do cartão');
        }

        if ($this->validateDni($posted[$this->id . '_doc'])) {
            throw new Exception('CPF ou CNPJ inválido');
        }

        return true;
    }

    public function validateDni($number)
    {
        $number = preg_replace('/[^0-9]/', '', (string)$number);

        if (strlen($number) == 14) {
            return $this->validateCNPJ($number);
        }

        if (strlen($number) == 11) {
            return $this->validateCPF($number);
        }

        return false;
    }

    public function validateCNPJ($cnpj)
    {
        if (strlen($cnpj) != 14) {
            return false;
        }

        for ($i = 0, $j = 5, $soma = 0; $i < 12; $i++) {
            $soma += $cnpj{$i} * $j;
            $j    = ($j == 2) ? 9 : $j - 1;
        }

        $resto = $soma % 11;

        if ($cnpj{12} != ($resto < 2 ? 0 : 11 - $resto)) {
            return false;
        }

        for ($i = 0, $j = 6, $soma = 0; $i < 13; $i++) {
            $soma += $cnpj{$i} * $j;
            $j    = ($j == 2) ? 9 : $j - 1;
        }

        $resto = $soma % 11;

        return $cnpj{13} == ($resto < 2 ? 0 : 11 - $resto);

    }

    public function validateCPF($cpf)
    {
        if (strlen($cpf) != 11) {
            return false;
        }

        if (str_repeat(substr($cpf, 0, 1), 11) == $cpf) {
            return false;
        }
        for ($t = 9; $t < 11; $t++) {
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf{$c} * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ($cpf{$c} != $d) {
                return false;
            }
        }

        return true;
    }

    protected function validate_installments($posted, $order_total)
    {
        if (!isset($posted['payu_credit_installments']) && 1 == $this->installments) {
            return true;
        }

        try {
            if (!isset($posted['payu_credit_installments']) || '' === $posted['payu_credit_installments']) {
                throw new Exception('Por favor, informe o número de parcelas');
            }

            $installments = absint($posted['payu_credit_installments']);
            $min_value    = $this->get_option('min_parcels_value');
            $max_parcels  = $this->get_option('max_parcels_number');

            if ($installments > $max_parcels || ($min_value != 0 && $order_total / $installments < $min_value)) {
                throw new Exception('Número inválido de parcelas');
            }
        } catch (Exception $e) {
            $this->add_error($e->getMessage());

            return false;
        }

        return true;
    }
}
