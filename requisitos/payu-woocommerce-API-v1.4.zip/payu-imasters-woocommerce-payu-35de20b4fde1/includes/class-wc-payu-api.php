<?php

class WC_PayU_API
{

    const PRODUCTION_URL = 'https://api.payulatam.com';

    const TEST_URL = 'https://sandbox.api.payulatam.com';

    protected $gateway;

    private $endpoint;

    private $test = false;

    public function __construct($gateway = null)
    {
        $this->gateway = $gateway;

        $this->environment = $gateway->environment;
        $this->account_id = $gateway->account_id;
        $this->merchant_id = $gateway->merchant_id;
        $this->api_login = $gateway->api_login;
        $this->api_key = $gateway->api_key;
        $this->public_key = $gateway->public_key;
        $this->test = $this->environment == 'test';

        $this->endpoint = $this->environment == 'test' ? self::TEST_URL : self::PRODUCTION_URL;
    }

    public function requestPromotions($amount)
    {
        $this->_sendRequestPromotions($amount);

        $json = json_decode($this->response);

        return $json;
    }

    private function _sendRequestPromotions($amount)
    {
        $method = "GET";
        $date = gmdate("D, d M Y H:i:s", time()) . " GMT";
        $url = '/payments-api/rest/v4.3/pricing';
        $signature = base64_encode(hash_hmac('sha256', utf8_encode($method . "\n" . "\n" . "\n" . $date . "\n" . $url),
            $this->gateway->api_key, true));

        $query = '?' . http_build_query(array(
                'accountId' => $this->gateway->account_id,
                'currency' => 'BRL',
                'amount' => $amount,
                'paymentMethod' => 'MASTERCARD'
            ));

        $curl = $this->curl(array(
            'Accept: application/json',
            'Authorization: Hmac ' . $this->gateway->public_key . ":" . $signature,
            'Date: ' . $date
        ), $this->endpoint . $url . $query);

        $this->response = curl_exec($curl);

        $erno = curl_errno($curl);

        if (!$this->response || $erno != 0) {
            return false;
        }

        curl_close($curl);

        return true;
    }

    private function curl(array $headers, $url = null)
    {
        if ($url === null) {
            $url = $this->endpoint;
        }

        $curl = curl_init($url);

        curl_setopt($curl, CURLOPT_FAILONERROR, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl, CURLOPT_TIMEOUT, 60);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        return $curl;
    }

    public function requestTransaction(
        $order,
        $id,
        $card_brand,
        $device_session_id,
        $installments = 0,
        $credit_card_data = array()
    ) {
        $authType = 'AUTHORIZATION_AND_CAPTURE';
        $referenceCode = 'Woocommerce-API - ' . $order->get_order_number();

        $data = new stdClass();
        $data->command = 'SUBMIT_TRANSACTION';
        $data->language = 'pt';

        $data->merchant = new stdClass();
        $data->merchant->apiKey = $this->api_key;
        $data->merchant->apiLogin = $this->api_login;

        $data->test = $this->test;

        if ($card_brand !== 'boleto_bancario') {
            $data->transaction = new stdClass();
            $data->transaction->creditCard = new stdClass();
            $data->transaction->creditCard->number = $credit_card_data['card_number'];
            $data->transaction->creditCard->securityCode = $credit_card_data['card_cvv'];
            $data->transaction->creditCard->expirationDate = $credit_card_data['card_expiration'];
            $data->transaction->creditCard->name = $credit_card_data['name_on_card'];

            $data->transaction->extraParameters = new stdClass();
            $data->transaction->extraParameters->INSTALLMENTS_NUMBER = $installments;

            if (!$this->gateway->auto_capture) {
                $authType = 'AUTHORIZATION';
            }
        } else {
            $this->test = false;

            $data->test = false;
            $data->transaction->expirationDate = date("c", strtotime(sprintf("+%d days", $installments)));
        }

        $data->transaction->ipAddress = filter_var($order->get_customer_ip_address());

        $data->transaction->order = new stdClass();
        $data->transaction->order->accountId = $this->account_id;
        $data->transaction->order->referenceCode = $referenceCode;
        $data->transaction->order->description = substr(sprintf('Order notes: %s',
            implode(' ', $order->get_customer_order_notes())), 0, 255);
        $data->transaction->order->language = 'pt';
        $data->transaction->order->signature = hash('sha256', sprintf('%s~%s~%s~%s~%s', $this->api_key, $this->merchant_id,
            $referenceCode, $order->get_total(), 'BRL'));
        $data->transaction->order->notifyUrl = '';

        $data->transaction->order->additionalValues = new stdClass();
        $data->transaction->order->additionalValues->TX_VALUE = new stdClass();
        $data->transaction->order->additionalValues->TX_VALUE->value = $order->get_total();
        $data->transaction->order->additionalValues->TX_VALUE->currency = 'BRL';

        $data->transaction->order->buyer = new stdClass();
        $data->transaction->order->buyer->merchantBuyerId = $order->get_customer_id();
        $data->transaction->order->buyer->fullName = $order->get_formatted_billing_full_name();
        $data->transaction->order->buyer->emailAddress = $order->get_billing_email();
        $data->transaction->order->buyer->contactPhone = $order->get_billing_phone();
        $data->transaction->order->buyer->dniNumber = $credit_card_data['card_doc'];
        $data->transaction->order->buyer->shippingAddress = new stdClass();
        $data->transaction->order->buyer->shippingAddress->street1 = $order->get_shipping_address_1();
        $data->transaction->order->buyer->shippingAddress->street2 = $order->get_shipping_address_2();
        $data->transaction->order->buyer->shippingAddress->city = $order->get_shipping_city();
        $data->transaction->order->buyer->shippingAddress->state = $this->translateState($order->get_shipping_state());
        $data->transaction->order->buyer->shippingAddress->country = $this->translateCountry($order->get_shipping_country());
        $data->transaction->order->buyer->shippingAddress->postalCode = $order->get_shipping_postcode();
        $data->transaction->order->buyer->shippingAddress->phone = $order->get_billing_phone();

        $data->transaction->payer = new stdClass();
        $data->transaction->payer->merchantPayerId = $order->get_customer_id();
        $data->transaction->payer->fullName = $order->get_formatted_billing_full_name();
        $data->transaction->payer->emailAddress = $order->get_billing_email();
        $data->transaction->payer->contactPhone = $order->get_billing_phone();
        $data->transaction->payer->dniNumber = $credit_card_data['card_doc'];
        $data->transaction->payer->billingAddress = new stdClass();
        $data->transaction->payer->billingAddress->street1 = $order->get_billing_address_1();
        $data->transaction->payer->billingAddress->street2 = $order->get_billing_address_2();
        $data->transaction->payer->billingAddress->city = $order->get_billing_city();
        $data->transaction->payer->billingAddress->state = $this->translateState($order->get_billing_state());
        $data->transaction->payer->billingAddress->country = $this->translateCountry($order->get_billing_country());
        $data->transaction->payer->billingAddress->postalCode = $order->get_billing_postcode();
        $data->transaction->payer->billingAddress->phone = $order->get_billing_phone();

        $data->transaction->type = $authType;

        $data->transaction->paymentMethod = strtoupper($card_brand);
        $data->transaction->paymentCountry = 'BR';

        $data->transaction->deviceSessionId = $device_session_id;
        $data->transaction->cookie = $_COOKIE['woocommerce_cart_hash'];
        $data->transaction->userAgent = $order->get_customer_user_agent();

        $json = $this->trySendRequest($data, $this->endpoint . '/payments-api/4.0/service.cgi');

        if (!is_object($json)) {
            return $this->get_default_error_message();
        }

        return $json;
    }

    private function translateState($state)
    {
        $states = array(
            'Rondônia' => 'RO',
            'Acre' => 'AC',
            'Amazonas' => 'AM',
            'Roraima' => 'RR',
            'Pará' => 'PA',
            'Amapá' => 'AP',
            'Tocantins' => 'TO',
            'Maranhão' => 'MA',
            'Piauí' => 'PI',
            'Ceará' => 'CE',
            'Rio Grande do Norte' => 'RN',
            'Paraíba' => 'PB',
            'Pernambuco' => 'PE',
            'Alagoas' => 'AL',
            'Sergipe' => 'SE',
            'Bahia' => 'BA',
            'Minas Gerais' => 'MG',
            'Espírito Santo' => 'ES',
            'Rio de Janeiro' => 'RJ',
            'São Paulo' => 'SP',
            'Paraná' => 'PR',
            'Santa Catarina' => 'SC',
            'Rio Grande do Sul' => 'RS',
            'Mato Grosso do Sul' => 'MS',
            'Mato Grosso' => 'MT',
            'Goiás' => 'GO',
            'Distrito Federal' => 'DF'
        );

        if (isset($states[$state])) {
            return $states[$state];
        }

        return $state;
    }

    private function translateCountry($country)
    {
        return 'BR';
    }

    private function trySendRequest($data, $url = null)
    {
        $json = null;
        $maxAttempts = 3;
        $request = json_encode($data);

        while ($maxAttempts > 0) {
            if ($this->_sendRequest($request, $url)) {
                $json = json_decode($this->response);

                break;
            }

            $maxAttempts--;
        }

        if ($maxAttempts == 0) {
            if ('yes' == $this->gateway->debug) {
                $this->gateway->log->add($this->gateway->id, 'An error occurred while requesting the transaction');
            }
        }

        return $json;
    }

    private function _sendRequest($postMsg, $url = null)
    {
        $curl = $this->curl(array(
            'Content-Type: application/json',
            'Accept: application/json'
        ), $url);

        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postMsg);

        $this->response = curl_exec($curl);

        $erno = curl_errno($curl);

        if (!$this->response || $erno != 0) {
            $this->gateway->log->add($this->gateway->id, sprintf("Error %s\n", curl_error($curl)));
            return false;
        }

        curl_close($curl);

        return $this->response;
    }

    protected function get_default_error_message()
    {
        $error = new StdClass();
        $error->mensagem = 'Um erro ocorreu durante o processamento do seu pagamento';

        return $error;
    }

    public function requestToken($ownerData)
    {
        $data = new stdClass();
        $data->command = 'CREATE_TOKEN';
        $data->language = 'pt';

        $data->merchant = new stdClass();
        $data->merchant->apiKey = $this->api_key;
        $data->merchant->apiLogin = $this->api_login;

        $data->creditCardToken = new stdClass();
        $data->creditCardToken->payerId = $this->billingAddress['customer_id'];
        $data->creditCardToken->name = $ownerData['name'];
        $data->creditCardToken->identificationNumber = $ownerData['own_doc'];
        $data->creditCardToken->paymentMethod = strtoupper($ownerData['issuer']);
        $data->creditCardToken->number = $ownerData['number'];
        $data->creditCardToken->expirationDate = $ownerData['exp_date'];

        $data->test = $this->test;

        $json = $this->trySendRequest($data, $this->endpoint . '/payments-api/4.0/service.cgi');

        return $json;
    }

    public function do_transaction_consultation($order, $tid, $id)
    {
        $data = new stdClass();
        $data->command = 'ORDER_DETAIL';
        $data->language = 'pt';

        $data->merchant = new stdClass();
        $data->merchant->apiKey = $this->api_key;
        $data->merchant->apiLogin = $this->api_login;

        $data->test = $this->test;
        $data->details = new stdClass();
        $data->details->orderId = (int)$id;

        $json = $this->trySendRequest($data, $this->endpoint . '/reports-api/4.0/service.cgi');

        return $json;
    }

    public function do_transaction_cancellation($order, $tid, $id, $amount = 0)
    {
        return $this->requestCancellation($order, $tid, $amount);
    }

    public function requestCancellation($order, $tid, $value)
    {
        $order_id = get_post_meta($order->id, '_wc_payu_order_id', true);

        $data = new stdClass();
        $data->command = 'SUBMIT_TRANSACTION';
        $data->language = 'pt';

        $data->merchant = new stdClass();
        $data->merchant->apiKey = $this->api_key;
        $data->merchant->apiLogin = $this->api_login;

        $data->test = $this->test;

        $data->transaction = new stdClass();
        $data->transaction->type = 'REFUND';
        $data->transaction->order = new stdClass();
        $data->transaction->order->id = $order_id;
        $data->transaction->reason = 'Refund requested by Merchant';
        $data->transaction->parentTransactionId = $tid;

        if ($value != 0) {
            $data->transaction->type = 'PARTIAL_REFUND';
            $data->transaction->additionalValues = new stdClass();
            $data->transaction->additionalValues->TX_VALUE = new stdClass();
            $data->transaction->additionalValues->TX_VALUE->value = $value;
            $data->transaction->additionalValues->TX_VALUE->currency = 'BRL';
        }

        $json = $this->trySendRequest($data, $this->endpoint . '/payments-api/4.0/service.cgi');

        return $json;
    }

    public function do_transaction_capture($order, $tid)
    {
        return $this->requestCapture($order, $tid);
    }

    public function requestCapture($order, $tid)
    {
        $order_id = get_post_meta($order->id, '_wc_payu_order_id', true);

        $data = new stdClass();
        $data->command = 'SUBMIT_TRANSACTION';
        $data->language = 'pt';

        $data->merchant = new stdClass();
        $data->merchant->apiKey = $this->api_key;
        $data->merchant->apiLogin = $this->api_login;

        $data->test = $this->test;

        $data->transaction = new stdClass();
        $data->transaction->type = 'CAPTURE';
        $data->transaction->order = new stdClass();
        $data->transaction->order->id = $order_id;
        $data->transaction->parentTransactionId = $tid;

        $json = $this->trySendRequest($data, $this->endpoint . '/payments-api/4.0/service.cgi');

        return $json;
    }
}
