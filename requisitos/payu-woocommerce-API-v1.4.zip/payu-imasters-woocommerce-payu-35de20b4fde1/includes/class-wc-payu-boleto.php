<?php

class WC_PayU_Boleto extends WC_PayU_Abstract
{
    public $api = null;

    public function __construct()
    {
        $this->id = 'payu_boleto';
        $this->has_fields = true;
        $this->method_title = 'Boleto bancário';
        $this->method_description = 'Habilita e configura o boleto bancário';
        $this->supports = array(
            'products'
        );

        $this->init_form_fields();

        $this->init_settings();

        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->environment = $this->get_option('environment');
        $this->account_id = $this->get_option('account_id');
        $this->merchant_id = $this->get_option('merchant_id');
        $this->api_login = $this->get_option('api_login');
        $this->api_key = $this->get_option('api_key');
        $this->public_key = $this->get_option('public_key');
        $this->expiration_date = $this->get_option('expiration_date');
        $this->debug = $this->get_option('debug');

        if ('yes' == $this->debug) {
            $this->log = $this->get_logger();
        }

        $this->api = new WC_PayU_API($this);

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(
            $this,
            'process_admin_options'
        ));
        add_action('woocommerce_api_wc_payu_boleto_gateway', array(
            $this,
            'check_return'
        ));
        add_action('woocommerce_thankyou_' . $this->id, array(
            $this,
            'thankyou_page'
        ));
        add_action('wp_enqueue_scripts', array(
            $this,
            'checkout_scripts'
        ), 999);

        add_filter('woocommerce_get_order_item_totals', array(
            $this,
            'order_items_payment_details'
        ), 10, 2);
    }

    public function init_form_fields()
    {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Habilita/Desabilita',
                'type' => 'checkbox',
                'label' => 'Habilita boleto bancário',
                'default' => 'yes'
            ),
            'title' => array(
                'title' => 'Título',
                'type' => 'text',
                'default' => 'Boleto bancário'
            ),

            'payu' => array(
                'title' => 'Configuração geral',
                'type' => 'title'
            ),
            'environment' => array(
                'title' => 'Ambiente',
                'type' => 'select',
                'description' => 'Escolha o ambiente',
                'desc_tip' => true,
                'class' => 'wc-enhanced-select',
                'default' => 'test',
                'options' => array(
                    'test' => 'Testes',
                    'production' => 'Produção'
                )
            ),
            'account_id' => array(
                'title' => 'ID Conta',
                'type' => 'text',
                'default' => ''
            ),
            'merchant_id' => array(
                'title' => 'ID Comércio',
                'type' => 'text',
                'default' => ''
            ),
            'api_login' => array(
                'title' => 'API Login',
                'type' => 'text',
                'default' => ''
            ),
            'api_key' => array(
                'title' => 'API Key',
                'type' => 'text',
                'default' => ''
            ),
            'public_key' => array(
                'title' => 'Public Key',
                'type' => 'text',
                'default' => ''
            ),

            'boleto_options' => array(
                'title' => 'Configuração de boleto',
                'type' => 'title'
            ),
            'expiration_date' => array(
                'title' => 'Vencicmento do boleto em',
                'type' => 'select',
                'class' => 'wc-enhanced-select',
                'default' => '3',
                'options' => array(
                    '1' => '1 dia',
                    '2' => '2 dias',
                    '3' => '3 dias',
                    '4' => '4 dias',
                    '5' => '5 dias'
                )
            ),
            'debug' => array(
                'title' => 'Depuração',
                'type' => 'checkbox',
                'label' => 'Ativa logs de depuração',
                'default' => 'no'
            )
        );
    }

    public function checkout_scripts()
    {
        if (!is_checkout()) {
            return;
        }

        if (!$this->is_available()) {
            return;
        }
    }

    protected function get_checkout_form($order_total = 0)
    {
        $wc_get_template = 'woocommerce_get_template';

        if (function_exists('wc_get_template')) {
            $wc_get_template = 'wc_get_template';
        }

        $wc_get_template('boleto/payu-payment-form.php', array(
            'expipration_date' => $this->expiration_date
        ), 'woocommerce/payu/', WC_PayU::get_templates_path());
    }

    protected function process_payu_payment($order)
    {
        $valid = $this->validate_holder_doc($_POST);

        if ($valid) {
            $response = $this->api->requestTransaction($order, $order->id, 'boleto_bancario',
                isset($_POST['payu_device_session_id']) ? $_POST['payu_device_session_id'] : '', 1, array(
                    'card_doc' => $_POST['payu_boleto_doc']
                ));

            if (!empty($response->error)) {
                $this->add_error((string)$response->error);
                $valid = false;
            }

            if (isset($response->transactionResponse)) {
                update_post_meta($order->id, '_transaction_id', (string)$response->transactionResponse->transactionId);
                update_post_meta($order->id, '_wc_payu_transaction_id', $response->transactionResponse->transactionId);
                update_post_meta($order->id, '_wc_payu_order_id', $response->transactionResponse->orderId);
                update_post_meta($order->id, '_wc_payu_status', $response->transactionResponse->state);

                if (isset($response->transactionResponse->extraParameters->URL_BOLETO_BANCARIO)) {
                    update_post_meta($order->id, '_wc_payu_boleto_url',
                        $response->transactionResponse->extraParameters->URL_BOLETO_BANCARIO);
                    update_post_meta($order->id, '_wc_payu_boleto_barcode',
                        $response->transactionResponse->extraParameters->BAR_CODE);

                    $order->update_status('on-hold', 'Awaiting boleto payment');
                    $order->reduce_order_stock();
                }

                $this->process_order_status($order, $response->transactionResponse->state, '');
            } else {
                $this->process_order_status($order, $response->code, $response->error);
                $valud = false;
            }

            update_post_meta($order->id, '_wc_payu_card_brand', $card_brand);
            update_post_meta($order->id, '_wc_payu_installments', $installments);
        }

        if ($valid) {
            return array(
                'result' => 'success',
                'redirect' => $this->get_return_url($order)
            );
        } else {
            return array(
                'result' => 'fail',
                'redirect' => ''
            );
        }
    }
}
