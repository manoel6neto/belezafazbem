<?php

class WC_PayU_Credit extends WC_PayU_Abstract
{

    public $api = null;

    public function __construct()
    {
        $this->id = 'payu_credit';
        $this->has_fields = true;
        $this->method_title = 'Cartão de crédito';
        $this->method_description = 'Habilita e configura pagamentos com cartão de crédito';
        $this->supports = array(
            'products',
            'refunds'
        );

        $this->init_form_fields();

        $this->init_settings();

        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');

        $this->environment = $this->get_option('environment');
        $this->account_id = $this->get_option('account_id');
        $this->merchant_id = $this->get_option('merchant_id');
        $this->api_login = $this->get_option('api_login');
        $this->api_key = $this->get_option('api_key');
        $this->public_key = $this->get_option('public_key');

        $this->card_types = $this->get_option('card_types');
        $this->auto_capture = $this->get_option('auto_capture');
        $this->max_parcels_number = $this->get_option('max_parcels_number');
        $this->min_parcels_value = $this->get_option('min_parcels_value');

        $this->debug = $this->get_option('debug');

        if ('yes' == $this->debug) {
            $this->log = $this->get_logger();
        }

        $this->api = new WC_PayU_API($this);

        if (!$this->auto_capture) {
            add_action('woocommerce_order_status_completed', array(
                $this,
                'process_capture'
            ));
        }
        add_action('woocommerce_order_status_cancelled', array(
            $this,
            'process_refund'
        ));
        add_action('woocommerce_order_status_refunded', array(
            $this,
            'process_refund'
        ));

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(
            $this,
            'process_admin_options'
        ));
        add_action('woocommerce_api_wc_payu_credit', array(
            $this,
            'check_return'
        ));
        add_action('woocommerce_thankyou_' . $this->id, array(
            $this,
            'thankyou_page'
        ));
        add_action('wp_enqueue_scripts', array(
            $this,
            'checkout_scripts'
        ));

        add_action('woocommerce_order_item_add_action_buttons', array(
            $this,
            'order_add_buttons'
        ));

        add_filter('woocommerce_get_order_item_totals', array(
            $this,
            'order_items_payment_details'
        ), 10, 2);
    }

    public function init_form_fields()
    {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Habilita/Desabilita',
                'type' => 'checkbox',
                'label' => 'Habilita cartão de crédito',
                'default' => 'yes'
            ),
            'title' => array(
                'title' => 'Título',
                'type' => 'text',
                'default' => 'Cartão de crédito'
            ),

            'payu' => array(
                'title' => 'Configuração geral',
                'type' => 'title'
            ),
            'environment' => array(
                'title' => 'Ambiente',
                'type' => 'select',
                'description' => 'Escolha o ambiente',
                'desc_tip' => true,
                'class' => 'wc-enhanced-select',
                'default' => 'test',
                'options' => array(
                    'test' => 'Testes',
                    'production' => 'Produção'
                )
            ),
            'account_id' => array(
                'title' => 'ID Conta',
                'type' => 'text',
                'default' => ''
            ),
            'merchant_id' => array(
                'title' => 'ID Comércio',
                'type' => 'text',
                'default' => ''
            ),
            'api_login' => array(
                'title' => 'API Login',
                'type' => 'text',
                'default' => ''
            ),
            'api_key' => array(
                'title' => 'API Key',
                'type' => 'text',
                'default' => ''
            ),
            'public_key' => array(
                'title' => 'Public Key',
                'type' => 'text',
                'default' => ''
            ),

            'credit_options' => array(
                'title' => 'Configuracões de cartão de crédito',
                'type' => 'title'
            ),
            'card_types' => array(
                'title' => 'Bandeiras aceitas',
                'type' => 'multiselect',
                'class' => 'wc-enhanced-select',
                'default' => array(
                    'visa',
                    'mastercard',
                    'amex',
                    'diners',
                    'hipercard',
                    'elo'
                ),
                'options' => array(
                    'visa' => 'Visa',
                    'mastercard' => 'MasterCard',
                    'amex' => 'American Express',
                    'diners' => 'Diners',
                    'hipercard' => 'Hipercard',
                    'elo' => 'Elo'
                )
            ),
            'auto_capture' => array(
                'title' => 'Autorização e captura',
                'type' => 'select',
                'class' => 'wc-enhanced-select',
                'default' => '2',
                'options' => array(
                    '1' => 'Autorize e capture automaticamente',
                    '0' => 'Apenas autorize'
                )
            ),
            'min_parcels_value' => array(
                'title' => 'Valor da menor parcela',
                'type' => 'text',
                'default' => '5'
            ),
            'max_parcels_number' => array(
                'title' => 'Máximo de parcelas',
                'type' => 'select',
                'class' => 'wc-enhanced-select',
                'default' => '1',
                'options' => array(
                    '1' => '1x',
                    '2' => '2x',
                    '3' => '3x',
                    '4' => '4x',
                    '5' => '5x',
                    '6' => '6x',
                    '7' => '7x',
                    '8' => '8x',
                    '9' => '9x',
                    '10' => '10x',
                    '11' => '11x',
                    '12' => '12x'
                )
            ),
            'debug' => array(
                'title' => 'Depuração',
                'type' => 'checkbox',
                'label' => 'Ativa logs de depuração',
                'default' => 'no'
            )
        );
    }

    public function order_add_buttons()
    {
    }

    public function get_installment_text($quantity, $order_total)
    {
        $installments = $this->get_installments($order_total);

        return $installments[$quantity - 1]['label'];
    }

    public function checkout_scripts()
    {
        if (!is_checkout()) {
            return;
        }

        if (!$this->is_available()) {
            return;
        }

        wp_enqueue_style('wc-payu-checkout-webservice');
    }

    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $order = new WC_Order($order_id);

        if (!$order || !$order->get_transaction_id()) {
            return false;
        }

        $diff = (strtotime($order->order_date) - strtotime(current_time('mysql')));
        $days = absint($diff / (60 * 60 * 24));
        $limit = 90;

        if ($limit > $days) {
            $tid = $order->get_transaction_id();
            $amount = wc_format_decimal($amount);
            $response = $this->api->do_transaction_cancellation($order, $tid, $order->id, $amount);

            if (!empty($response->error)) {
                $order->add_order_note('PayU: ' . sanitize_text_field($response->error));

                return new WP_Error('payu_refund_error', sanitize_text_field($response->error));
            } else {
                $order->add_order_note(sprintf('PayU: %s - valor reembolsado: %s.',
                    sanitize_text_field($response->transactionResponse->state), wc_price($amount)));

                return true;
            }
        } else {
            return new WP_Error('payu_refund_error',
                sprintf('Essa transação foi feita há mais de %d e não pode mais ser cancelada na PayU', $limit));
        }

        return false;
    }

    public function process_capture($order_id)
    {
        $order = new WC_Order($order_id);

        if (!$order || !$order->get_transaction_id()) {
            return false;
        }

        $tid = $order->get_transaction_id();
        $response = $this->api->do_transaction_capture($order, $tid);

        if (!empty($response->error)) {
            $order->add_order_note('Pay: ' . sanitize_text_field($response->error));

            return new WP_Error('payu_capture_error', sanitize_text_field($response->error));
        } else {
            if ($response->transactionResponse->state == 'ERROR') {
                $order->add_order_note(sprintf('PayU[Capture] %s - %s',
                    sanitize_text_field($response->transactionResponse->responseCode),
                    sanitize_text_field($response->transactionResponse->responseMessage)));

                return new WP_Error('payu_capture_error', sanitize_text_field($response->error));
            } else {
                $order->add_order_note(sprintf('PayU[Capture - %s] %s',
                    sanitize_text_field($response->transactionResponse->state), sanitize_text_field($tid)));

                return true;
            }
        }
    }

    protected function get_checkout_form($order_total = 0)
    {
        $wc_get_template = 'woocommerce_get_template';

        if (function_exists('wc_get_template')) {
            $wc_get_template = 'wc_get_template';
        }

        $wc_get_template('credit-card/payu-payment-form.php', array(
            'installments' => $this->get_installments($order_total)
        ), 'woocommerce/payu/', WC_PayU::get_templates_path());
    }

    public function get_installments($order_total = 0)
    {
        $installments = [];
        $min_value = $this->min_parcels_value;
        $max_parcels = $this->max_parcels_number;

        $promotions = $this->api->requestPromotions($order_total);

        foreach ($promotions->paymentMethodFee[0]->pricingFees as $pricingFees) {
            $installment = array(
                'num' => $pricingFees->installments,
                'label' => ''
            );

            if ($pricingFees->installments == 1) {
                $installment['label'] = sprintf('R$ %.02f à vista', $pricingFees->pricing->totalValue);
            } elseif ($pricingFees->installments > 1) {
                if ($pricingFees->installments > $max_parcels) {
                    break;
                }

                if ($min_value != 0 && $order_total / $pricingFees->installments < $min_value) {
                    break;
                }

                $installment['label'] = sprintf('%d x de R$ %.02f', $pricingFees->installments,
                    $pricingFees->pricing->totalValue / $pricingFees->installments);

                if ($pricingFees->pricing->totalValue > $order_total) {
                    $installment['label'] .= sprintf(' (juros de R$ %.02f)',
                        $pricingFees->pricing->totalValue - $order_total);
                } else {
                    $installment['label'] .= ' (sem juros)';
                }
            }

            $installments[] = $installment;
        }

        if (count($installments) == 0) {
            $installments[] = array(
                'num' => 1,
                'label' => sprintf('R$ %.02f à vista', $order_total)
            );
        }

        return $installments;
    }

    protected function process_payu_payment($order)
    {
        $card_number = isset($_POST['payu_credit_number']) ? sanitize_text_field($_POST['payu_credit_number']) : '';
        $card_brand = $this->get_card_brand($card_number);

        $valid = $this->validate_credit_brand($card_brand);

        if ($valid) {
            $valid = $this->validate_card_number($card_number);
        }

        if ($valid) {
            $valid = $this->validate_card_fields($_POST, $card_brand);
        }

        if ($valid) {
            $valid = $this->validate_installments($_POST, $order->order_total);
        }

        if ($valid) {
            $installments = isset($_POST['payu_credit_installments']) ? absint($_POST['payu_credit_installments']) : 1;
            $card_data = array(
                'name_on_card' => $_POST['payu_credit_holder_name'],
                'card_number' => preg_replace('/[^\d]/', '', $_POST['payu_credit_number']),
                'card_expiration' => implode("/", array_reverse(explode(" / ", $_POST['payu_credit_expiry']))),
                'card_cvv' => $_POST['payu_credit_cvc'],
                'card_doc' => $_POST['payu_credit_doc']
            );

            $response = $this->api->requestTransaction($order, $order->id, $card_brand,
                isset($_POST['payu_device_session_id']) ? $_POST['payu_device_session_id'] : '', $installments,
                $card_data);

            if (!empty($response->error)) {
                $this->add_error((string)$response->error);
                $valid = false;
            }

            if (isset($response->transactionResponse)) {
                update_post_meta($order->id, '_transaction_id', (string)$response->transactionResponse->transactionId);
                update_post_meta($order->id, '_wc_payu_transaction_id', $response->transactionResponse->transactionId);
                update_post_meta($order->id, '_wc_payu_order_id', $response->transactionResponse->orderId);
                update_post_meta($order->id, '_wc_payu_status', $response->transactionResponse->state);

                $this->process_order_status($order, $response->transactionResponse->state, '');
            } else {
                $this->process_order_status($order, $response->code, $response->error);
            }

            update_post_meta($order->id, '_wc_payu_card_brand', $card_brand);
            update_post_meta($order->id, '_wc_payu_installments', $installments);
        }

        if ($valid) {
            return array(
                'result' => 'success',
                'redirect' => $this->get_return_url($order)
            );
        } else {
            return array(
                'result' => 'fail',
                'redirect' => ''
            );
        }
    }

    public function get_card_brand($number)
    {
        $number = preg_replace('([^0-9])', '', $number);
        $brand = '';

        $supported_brands = array(
            'visa' => '/^4\d{12}(\d{3})?$/',
            'mastercard' => '/^(5[1-5]\d{4}|677189)\d{10}$/',
            'amex' => '/^3[47]\d{13}$/',
            'diners' => '/^3(0[0-5]|[68]\d)\d{11}$/',
            'hipercard' => '/^(606282\d{10}(\d{3})?)|(3841\d{15})$/',
            'elo' => '/^((((636368)|(438935)|(504175)|(451416)|(636297))\d{0,10})|((5067)|(4576)|(4011))\d{0,12})$/'
        );

        foreach ($supported_brands as $key => $value) {
            if (preg_match($value, $number)) {
                $brand = $key;
                break;
            }
        }

        return $brand;
    }
}
