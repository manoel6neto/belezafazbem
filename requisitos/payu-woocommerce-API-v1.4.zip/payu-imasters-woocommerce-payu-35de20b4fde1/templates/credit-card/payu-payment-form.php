<?php
if (!defined('ABSPATH')) {
    exit();
}
?>

<fieldset id="payu-credit-payment-form" class="payu-payment-form">
    <?php
    $sessionId = hash('sha256', $_COOKIE['woocommerce_cart_hash'] . microtime());
    $deviceSessionId = $sessionId . '80200';
    ?>
    <div style="display: none;">
        <p style="background:url(https://maf.pagosonline.net/ws/fp?id=<?php echo $deviceSessionId; ?>"></p>
        <img
                src="https://maf.pagosonline.net/ws/fp/clear.png?id=<?php echo $deviceSessionId; ?>"
                width="1" height="1">
        <script
                src="https://maf.pagosonline.net/ws/fp/check.js?id=<?php echo $deviceSessionId; ?>"></script>
        <object type="application/x-shockwave-flash"
                data="https://maf.pagosonline.net/ws/fp/fp.swf?id=<?php echo $deviceSessionId; ?>"
                width="1" height="1" id="thm_fp">

            <param name="movie"
                   value="https://maf.pagosonline.net/ws/fp/fp.swf?id=<?php echo $deviceSessionId; ?>"/>
        </object>

        <input name="payu_device_session_id" type="hidden"
               id="device_session_id" class="required-entry"
               value="<?php echo $sessionId; ?>">
    </div>

    <p class="form-row form-row-wide">
        <label for="payu-card-number">Número do cartão<span
                    class="required">*</span></label> <input id="payu-card-number"
                                                             name="payu_credit_number"
                                                             class="input-text wc-credit-card-form-card-number"
                                                             type="tel"
                                                             maxlength="22" autocomplete="off"
                                                             placeholder="&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;"
                                                             style="font-size: 1.5em; padding: 8px;"/>
    </p>

    <?php if (!empty($installments)) : ?>
        <p class="form-row form-row-wide">
            <label for="payu-installments">Parcelas<span
                        class="required">*</span></label> <select id="installments"
                                                                  name="payu_credit_installments">
                <?php
                foreach ($installments as $installment) {
                    printf('<option value="%d">%s</option>', $installment['num'], $installment['label']);
                }
                ?>
            </select>
        </p>
    <?php endif; ?>
    <p class="form-row form-row-wide">
        <label for="payu-card-holder-name">Nome impresso no cartão<span
                    class="required">*</span></label> <input id="payu-card-holder-name"
                                                             name="payu_credit_holder_name" class="input-text"
                                                             type="text"
                                                             autocomplete="off"
                                                             style="font-size: 1.5em; padding: 8px;"/>
    </p>
    <p class="form-row form-row-first">
        <label for="payu-card-expiry">Validade do cartão<span
                    class="required">*</span></label> <input id="payu-card-expiry"
                                                             name="payu_credit_expiry"
                                                             class="input-text wc-credit-card-form-card-expiry"
                                                             type="tel"
                                                             autocomplete="off"
                                                             placeholder="MM / AAAA"
                                                             style="font-size: 1.5em; padding: 8px;"/>
    </p>
    <p class="form-row form-row-last">
        <label for="payu-card-cvc">Código de segurança<span
                    class="required">*</span></label> <input id="payu-card-cvc"
                                                             name="payu_credit_cvc"
                                                             class="input-text wc-credit-card-form-card-cvc" type="tel"
                                                             autocomplete="off"
                                                             placeholder="CVC"
                                                             style="font-size: 1.5em; padding: 8px;"/>
    </p>
    <p class="form-row form-row-wide">
        <label for="payu-card-doc">CPF ou CNPJ<span
                    class="required">*</span></label> <input id="payu-card-doc"
                                                             name="payu_credit_doc" class="input-text" type="text"
                                                             autocomplete="off"
                                                             style="font-size: 1.5em; padding: 8px;"/>
    </p>
    <div class="clear"></div>
</fieldset>
