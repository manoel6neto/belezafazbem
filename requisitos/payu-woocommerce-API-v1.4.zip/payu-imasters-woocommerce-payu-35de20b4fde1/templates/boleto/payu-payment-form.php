<?php
if (!defined('ABSPATH')) {
    exit();
}

?>

<fieldset id="payu-boleto-payment-form" class="payu-payment-form">
    <?php
    $sessionId = hash('sha256', $_COOKIE['woocommerce_cart_hash'] . microtime());
    $deviceSessionId = $sessionId . '80200';
    ?>
    <div style="display: none;">
        <p style="background:url(https://maf.pagosonline.net/ws/fp?id=<?php echo $deviceSessionId; ?>"></p>
        <img
                src="https://maf.pagosonline.net/ws/fp/clear.png?id=<?php echo $deviceSessionId; ?>"
                width="1" height="1">
        <script
                src="https://maf.pagosonline.net/ws/fp/check.js?id=<?php echo $deviceSessionId; ?>"></script>
        <object type="application/x-shockwave-flash"
                data="https://maf.pagosonline.net/ws/fp/fp.swf?id=<?php echo $deviceSessionId; ?>"
                width="1" height="1" id="thm_fp">

            <param name="movie"
                   value="https://maf.pagosonline.net/ws/fp/fp.swf?id=<?php echo $deviceSessionId; ?>"/>
        </object>

        <input name="payu_device_session_id" type="hidden"
               id="device_session_id" class="required-entry"
               value="<?php echo $sessionId; ?>">
    </div>
    <p class="form-row form-row-wide">
        <label for="payu-boleto-doc">CPF ou CNPJ<span
                    class="required">*</span></label> <input id="payu-boleto-doc"
                                                             name="payu_boleto_doc" class="input-text" type="text"
                                                             autocomplete="off"
                                                             style="font-size: 1.5em; padding: 8px;"/>
    </p>
    <div class="clear"></div>
</fieldset>
