Thank you so much for downloading our theme
If you need help, please email us vedibadiyan@gmail.com, we will help you installing theme like demmo.


Please Follow The Instructions To Install Theme Correctly or email us we will set theme like demo for you.


Step:1

Note: This theme can only be installed opencart 2.1.x, 2.2.x, 2.3.x, 3.x versions, lower version 1.5.6.4 or less are not supported.
To Avoid any errors, please install the correct version of the opencart, or email us we will install it for you

Download the latest version of opencart and install it

upload  the following folders to the root of the opencart folder
admin,
catalog,
image,
system,
themeinstall

Note: Make sure, you choose the correct version of theme or you will get errors due to version mismatch, 
s
for opencart version 2.1.x, upload theme folder 2.1x
for opencart version 2.2.x, upload theme folder 2.2x
For opencart version 2.3.x, upload theme folder 2.3.x
For opencart version 2.3.x, upload theme folder 3.0.x

If you need help, email us vedibadiyan@gmail.com

Step:2 

Activate theme,

for opencart version 2.1.x, go to admin>>setting>>edit>>general tab and choose yuki and save
for opencart version 2.2.x, go to admin>> extensions >>themes>> choose yuki and save
for opencart version 2.3.x, go to admin>> extensions >>choose theme>>edit>>theme select yuki and save
for opencart version 3.0.x, go to admin>> extensions >>choose theme>>edit>>theme select yuki and save

If you need help, email us vedibadiyan@gmail.com



Step:3

For Images, We have used the following settings.
Go To Admin>>System>>Setting>>Edit>>Images

Set the images as following
* Category Image Size:900x400
* Product Image Thumb Size:500x500
* Product Image Popup Size:700x700
* Product Image List Size:228x228
* Additional Product Image Size:140x140
* Related Product Image Size:300x300
* Compare Image Size:90x90
* Wish List Image Size:47x47
* Cart Image Size:47x47

Step 4: For yuki theme options

Go to admin>>module>>yuki theme options>>edit>>active skin >>choose default full width and click on choose and save	

WATCH THE VIDEO GUIDE HERE
https://youtu.be/Uru-I6RNqJo


common issues after installing and handling. 

If you receive any errors or warning or installation errors, you can re-install it and upload a latest version of theme from site or create a support request, 

NOTE:  

For support and questions, go to the link below 

Step 1: go to http://forum.felixtheme.com/ sign up
Step 2: go to and create new request http://forum.felixtheme.com/support/  

Please re-install and send us the fresh version of opencart, so we can install it for you

or email us with screenshot, so we can help you and set up your site, email to vedibadiyan@gmail.com








