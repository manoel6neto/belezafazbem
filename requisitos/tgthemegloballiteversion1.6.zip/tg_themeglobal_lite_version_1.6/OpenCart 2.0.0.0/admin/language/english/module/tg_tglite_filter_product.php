<?php

// Heading Goes here:
$_['heading_title']    = 'TG ThemeGlobal Pro Filter Product <b> <a href="http://themeglobal.com/"> (Upgrage to Pro to use)</a></b>';

// Text
$_['text_success']     = 'Success: You have modified module TG ThemeGlobal Pro Filter Product!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module TG ThemeGlobal Pro Filter Product!';

?>
