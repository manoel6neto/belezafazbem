<?php

// Heading Goes here:
$_['heading_title']    = 'TG ThemeGlobal Pro MegaMenu <b> <a href="http://themeglobal.com/"> (Upgrage to Pro to use)</a></b>';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified module TG ThemeGlobal Pro MegaMenu !';
$_['text_warning']     = 'Warning: Changes have not been saved! Make sure you have completed all fields well.';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module TG ThemeGlobal Pro MegaMenu !';

?>
